export interface IUser {
  _id: string,
  email: string,
  name: string,
  gravatar: string,
  token:string
}