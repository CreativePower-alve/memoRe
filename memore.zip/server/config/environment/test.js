'use strict';

// Test specific configuration
// ===========================
module.exports = {
    // MongoDB connection options
    mongo: {
        uri: 'mongodb://localhost/memore-test'
    },
     'secret': 'super secret password!'
};